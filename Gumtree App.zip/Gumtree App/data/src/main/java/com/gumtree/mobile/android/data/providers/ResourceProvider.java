package com.gumtree.mobile.android.data.providers;

/**
 * Created by Android Developer on 4/5/2017.
 */

public interface ResourceProvider {

    int provideWhiteStarBorder();

    int provideWhiteStar();
}
