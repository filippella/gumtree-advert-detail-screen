package com.gumtree.mobile.android.data.pojo;

/**
 * Created by Android Developer on 4/5/2017.
 */

public interface AdvertInfo<M> {

    AdvertInfoType getType();

    M getModel();
}
