package com.gumtree.mobile.android.data.pojo;

/**
 * Created by Android Developer on 4/6/2017.
 */

public class Finance {

    public String title;
}
