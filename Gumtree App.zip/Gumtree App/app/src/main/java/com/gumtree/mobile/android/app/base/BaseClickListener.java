package com.gumtree.mobile.android.app.base;

/**
 * Created by Android Developer on 4/6/2017.
 */

public interface BaseClickListener {
}
